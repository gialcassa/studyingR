#variable -> tudo o que eu posso medir
#value -> o estado de determinada variável no momento em que vou medi-la
#observation -> conjunto de medidas feitas nas mesmas condições
#tabular data -> conjunto de valores, cada um deles associado a uma variável e dentro de uma observação

install.packages('tidyverse')

install.packages(
  c("arrow", "babynames", "curl", "duckdb", "gapminder",
    "ggrepel", "ggridges", "ggthemes", "hexbin", "janitor", "Lahman",
    "leaflet", "maps", "nycflights13", "openxlsx", "palmerpenguins",
    "repurrrsive", "tidymodels", "writexl"))

#precisamos carregar o pacote que vamos utilizar (só precisamos instalar uma vez, porém SEMPRE precisamos carregar na hora de utilizar)

library(tidyverse)

#vamos estudar os pinguins e a possível relação entre tamanho da nadadeira e massa corporal. Para isso, precisamos carregar um conjunto de dados sobre esses pinguins, e vamos carregar outro pacote, que vai tornar possível usar uma paleta para daltônicos na hora de plotar nosso gráfico

library(palmerpenguins)
library(ggthemes)

#vamos carregar o dataset para visualizá-lo

palmerpenguins::penguins

#usamos o "View" para ter uma visão melhor dos dados
View(penguins)

#podemos obter mais informações sobre aquele conjunto de dados usando "?"
?penguins

#nós vamos usar um pacote chamado ggplot (perguntar para o Marcelo pra que serve exatamente)

#para esse exercício, vamos usar o pacote ggplot2. Com ele, para começar um plot, usamos a função ggplot() e aí eu digo pra ele de qual dataset ele tem que puxar os dados

ggplot(data = penguins)

#temos uma tela vazia porque ainda não falamos para o ggplot como queremos que o gráfico seja
#vamos usar o "mapping" para dizer como vai ser o visual (aesthetics) do gráfico

#usamos aes() - aesthetic - para especificar o que vai no x e o que vai no y

ggplot(
  data = penguins,
  mapping = aes(x = flipper_length_mm, y = body_mass_g)
)

#ok, definimos o que fica onde, porém ainda não jogamos os dados (valores) no gráfico
#para isso, devemos definir qual vai ser o "geom", que é o objeto geométrico (linha, barra, boxplot etc.) que representará nossos dados

#vamos usar a função geom_point() para criar um gráfico scatterplot

ggplot(
  data = penguins,
  mapping = aes(x = flipper_length_mm, y = body_mass_g)
) +
  geom_point()

#esse scatterplot mostra que possivelmente há uma relação positiva (diretamente proporcional) entre tamanho da nadadeira e massa muscular; porém, precisamos pensar se não existem outras variáveis que influenciam isso, como por exemplo a espécie
#vamos dar um "highlight" nas espécies, indo no aes(), que é onde editamos nossas variáveis

ggplot(
  data = penguins,
  mapping = aes(x = flipper_length_mm, y = body_mass_g, color = species) #estou pedindo para que a linha seja "pintada" com as espécies
) +
  geom_point()

#quando uma variável categórica é mapeada em uma aesthetic, o ggplot2 vai automaticamente atribuir um valor único da aesthetic (cor) para cada nível único da variável (espécies)

#certo, agora vamos adicionar a linha para o nosso gráfico linear. No caso do ggplot, o código é "geom_smooth()" e adicionamos a informação de que queremos que seja baseado em um modelo linear (lm)

ggplot(
  data = penguins,
  mapping = aes(x = flipper_length_mm, y = body_mass_g, color = species)
) +
  geom_point() + #eu quero que tenha pontos, mas também quero que...
  geom_smooth(method = "lm") #... tenha uma linha

#esse código não deu um resultado satisfatório, porque ele criou três linhas (uma para cada espécie) em vez de apenas uma linha para os três. Nesse caso, precisamos ajustar isso

#quando definimos um "mapping" no topo de um código, essa "ordem" é passada para cada nível abaixo do código. Porém, também dá para adicionarmos um "mapping" nos níveis subsequentes também

ggplot(
  data = penguins,
  mapping = aes(x = flipper_length_mm, y = body_mass_g) #removi as espécies da plotagem
) +
  geom_point(mapping = aes(color = species)) + #eu quero as espécies separadas por cor, mas não quero que a plotagem inclua as espécies
  geom_smooth(method = "lm") 

#pronto, agora tenho apenas uma linha ajustada aos pontos!

#porém, dá para melhorar a visualização desse gráfico - por exemplo, atribuindo um formato para cada espécie e mudando a escala de cor para ajudar quem é daltônico

ggplot(
  data = penguins,
  mapping = aes(x = flipper_length_mm, y = body_mass_g) 
) +
  geom_point(mapping = aes(color = species, shape = species)) + #da mesma forma que separei por cor, posso separar por forma
  geom_smooth(method = "lm") 

#o gráfico está pronto, mas podemos melhorar seus "labels"

ggplot(
  data = penguins,
  mapping = aes(x = flipper_length_mm, y = body_mass_g)
) +
  geom_point(aes(color = species, shape = species)) +
  geom_smooth(method = "lm") +
  labs( #aqui eu começo a editar os labels (título, nome dos eixos etc.)
    title = "Relação entre massa corporal e tamanho da nadadeira", #aqui eu adiciono um título e subtítulo abaixo
    subtitle = "Comparando as espécies Adelie, Chinstrap, e Gentoo",
    x = "Tamanho da nadadeira (mm)", y = "Massa corporal (g)",
    color = "Species", shape = "Species"
  ) +
  scale_color_colorblind() #aqui eu adiciono um "filtro" para daltônicos


# VISUALIZANDO DISTRIBUIÇÕES ----------------------------------------------

# SOBRE VARIÁVEIS

# variáveis categóricas:armazenam UM valor dentre diversos valores. Para examinar a distribuição de uma variável, podemos usar um gráfico de barra

ggplot(penguins, aes(x = species)) + #mostra quantos penguins de cada espécie foram "coletados"
  geom_bar()

#para um gráfico de barra ficar mais "bonitinho", é melhor reorganizá-lo por ordem de distribuição

ggplot(penguins, aes(x = fct_infreq(species))) + #devemos transformar a variável em um fator (fct), que é a maneira que o R interpreta variáveis categóricas - e depois da transformação, reordenamos aqueles fatores
  geom_bar()


# variáveis numéricas (ou quantitativas): podem armazenar vários valores numéricos, e pode receber operações de soma, subtração, média etc. As variáveis numéricas podem ser discretas (números inteiros) ou contínuas (qualquer número dentro determinado intervalo)

# variáveis contínuas geralmente são representadas por meio de um histograma

ggplot(penguins, aes(x = body_mass_g)) +
  geom_histogram(binwidth = 200) #a largura da barra (binwidth) deve ser pensada de forma eficientem, pois ela determina o quão bem esses dados serão visualizados 

# como um histograma funciona? ele pega os valores de X e os divide dentro de intervalos. A altura das barras indica a frequência com que cada valor cai dentro desse intervalo

# outro exemplo de visualização de distribuição é por meio de gráficos de densidade

# um gráfico de densidade é uma versão mais "suave" e mais prática de um histograma, porque apesar de não ser tão detalhada quanto um histograma, mostra uma visualização que já faz a gente ter uma ideia da distribuição

?geom_density

ggplot(penguins, aes(x = body_mass_g)) +
  geom_density() # veja como o geom é importante para definirmos a maneira como visualizamos nossos dados


# exercícios

#1
ggplot(penguins, aes(y = fct_infreq(species))) +
  geom_bar()
  
#2

ggplot(penguins, aes(x = species)) +
  geom_bar(color = "red") #usando o "color" no caso das barras, o que acontece é que elas ficam apenas CONTORNADAS com essa cor

ggplot(penguins, aes(x = species)) +
  geom_bar(fill = "red") #usando fill, aí sim temos barras completamente daquela cor
  
# VISUALIZANDO RELAÇÕES

# até agora, visualizamos distribuições (o quanto tem de cada espécie, tamanho etc.). Agora vamos analisar relações (a maneira com que determinadas variáveis (x e y) se relacionam)

# uma maneira de visualizarmos a relação entre uma variável numérica e uma categórica, podemos utilizar boxplots lado a lado (side by side boxplots)

# o que é um boxplot? é uma visualização que mede posições (percentis) que descrevem uma distribuição, e pode ser útil para identificar outliers

# um boxplot consiste em:

# uma caixa que indica o range de metade dos dados, mais conhecido como amplitude interquartil (IQR - interquartile range), que começa a partir do 25º percentil e vai até o 75º percentil

# no meio da caixa está a mediana, que seria o 50º percentil da distribuição

# dois "bigodes" que saem de cada lado da caixa e vão até o último ponto não-outlier da distribuição

ggplot(penguins, aes(x = species, y = body_mass_g)) + # quero ver a distribuição da massa corporal entre as espécies
  geom_boxplot()

# gráficos de densidade 
# é como um gráfico de barras, só que em forma de curvas suaves, e quanto mais alto essa curva, significa que os dados estão concentrados ali

ggplot(penguins, aes(x = body_mass_g, color = species)) +
  geom_density(linewidth = 0.75)

# no caso do gráfico de densidade, também podemos deixá-los coloridinhos

ggplot(penguins, aes(x = body_mass_g, color = species, fill = species)) +
  geom_density(alpha = 0.5)

# duas variáveis categóricas

# dá para stackar gráficos de barra para analisar duas variáveis categórias

ggplot(penguins, aes(x = island, fill = species)) + #eu estou setando que as espécies preencham a barra (geom_bar)
  geom_bar() 

# no exemplo acima, estou comparando números absolutos, mas eu posso também fazer um gráfico de frequência relativa, que compara a proporção de cada categoria em relação ao total


ggplot(penguins, aes(x = island, fill = species)) + #eu estou setando que as espécies preencham a barra (geom_bar)
  geom_bar(position = "fill")

#"In creating these bar charts, we map the variable that will be separated into bars to the x aesthetic, and the variable that will change the colors inside the bars to the fill aesthetic."

#DUAS VARIÁVEIS NUMÉRICAS

# para duas variáveis numéricas, o mais comum é o scatterplot mesmo

ggplot(penguins, aes(x = flipper_length_mm, y = body_mass_g)) + #eu estou setando que as espécies preencham a barra (geom_bar)
  geom_point()

# TRÊS OU MAIS VARIÁVEIS

# como vimos, podemos analisar várias variáveis de uma só vez (espécie, tamanho, massa corporal etc.)

# porém, às vezes pode ficar difícil de analisar um gráfico que tem muitos mappings

ggplot(penguins, aes(x = flipper_length_mm, y = body_mass_g)) +
  geom_point(aes(color = species, shape = island)) #quero que tenha a cor que representa a espécie, mas também quero uma forma que represente a ilha

#então podemos dividir (facetar) nosso gráfico, usando o facet_wrap()

ggplot(penguins, aes(x = flipper_length_mm, y = body_mass_g)) +
  geom_point(aes(color = species, shape = species)) +
  facet_wrap(~island) #quero que isso tudo seja dividido ilha por ilha

# SALVANDO UM PLOT

ggplot(
  data = penguins,
  mapping = aes(x = flipper_length_mm, y = body_mass_g)
) +
  geom_point(aes(color = species, shape = species)) +
  geom_smooth(method = "lm") +
  labs( #aqui eu começo a editar os labels (título, nome dos eixos etc.)
    title = "Relação entre massa corporal e tamanho da nadadeira", #aqui eu adiciono um título e subtítulo abaixo
    subtitle = "Comparando as espécies Adelie, Chinstrap, e Gentoo",
    x = "Tamanho da nadadeira (mm)", y = "Massa corporal (g)",
    color = "Species", shape = "Species"
  ) +
  scale_color_colorblind()
ggsave(filename = "penguins.png")
